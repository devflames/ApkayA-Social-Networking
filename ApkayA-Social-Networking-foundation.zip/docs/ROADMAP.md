# Roadmap

## Phase 0 — Foundation

- Repository/IP boundary
- Architecture
- CI baseline
- Coding standards
- Environment model
- Theme plugin contract

## Phase 1 — Security

- Auth/session hardening
- CSRF
- RBAC
- Upload security
- Payment verification
- Security headers
- Audit logs

## Phase 2 — Core modernization

- Service boundaries
- Repository/data access layer
- Redis
- Queue system
- Structured logging
- Automated tests

## Phase 3 — UI platform

- Theme runtime
- Design tokens
- Component contracts
- Theme marketplace packaging
- Theme activation/rollback
- White-label branding

## Phase 4 — Media/realtime

- Object storage
- Async FFmpeg workers
- HLS/adaptive media
- Modern WebSocket layer
- Presence and notification queues

## Phase 5 — AI

- AI gateway
- Provider abstraction
- Assistant
- AI creator tools
- Moderation
- Semantic search/recommendations

## Phase 6 — Creator

- Subscriptions
- Tips
- Paid content
- Live monetization
- Creator analytics
- Payouts

## Phase 7 — Commerce

- Seller system
- Inventory/SKU
- Orders
- Shipping
- Refunds/disputes
- Marketplace analytics

## Phase 8 — Platform/licensing

- Extension SDK
- Theme marketplace
- Signed packages
- ApkayA license server
- Entitlements
- Enterprise editions

## Phase 9 — Production excellence

- Load testing
- Disaster recovery
- Observability
- Penetration testing
- Release engineering
- Documentation
