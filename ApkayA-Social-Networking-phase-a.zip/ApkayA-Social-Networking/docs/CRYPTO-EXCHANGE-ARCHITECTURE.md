# ApkayA Crypto Wallet & Exchange Architecture

## Goal

Build a production-grade crypto wallet and exchange subsystem inside ApkayA Social Networking. The target is a Binance-class product surface for spot trading, custody, deposits, withdrawals, market data, fees, compliance, and portfolio management.

This module is **not** a simple balance table. User balances must be derived from an immutable double-entry ledger and reconciled against blockchain/provider balances.

## Product scope

### Phase A — Wallet
- Multi-asset wallets
- Deposit addresses
- Deposit detection and confirmations
- Withdrawal requests and approvals
- Transaction history
- Network selection
- Fee estimation
- Address book / withdrawal allowlist
- QR codes
- Portfolio valuation
- Asset metadata
- Maintenance/deposit/withdrawal status

### Phase B — Spot exchange
- Markets and trading pairs
- Limit orders
- Market orders
- Cancel/replace
- Order book
- Matching engine
- Trade history
- User order history
- Trading fees
- Maker/taker accounting
- Market status and circuit breakers

### Phase C — Advanced exchange
- Stop orders
- OCO/conditional orders
- Advanced charting
- API keys and trading permissions
- Subaccounts
- Institutional controls
- Proof-of-reserves reporting

Margin, derivatives, perpetuals, and lending are deliberately deferred until the spot system, risk engine, custody, compliance, and accounting are independently validated.

## High-level architecture

```text
Web / Mobile / API Clients
          |
     API Gateway
          |
  +-------+--------+
  |                |
Wallet API     Exchange API
  |                |
  +-------+--------+
          |
     Domain Services
          |
  +-------+-------------------------------+
  |       |        |       |      |       |
Ledger  Custody  Assets  Orders  Risk  Compliance
  |       |        |       |      |       |
  |     HSM/MPC    |    Matching |   KYT/AML
  |       |        |    Engine   |
  +-------+--------+-------+-----+-------+
          |
      Event Bus / Queue
          |
  +-------+----------+-------------------+
  |                  |                   |
Blockchain        Market Data        Notifications
Adapters           Providers            / Webhooks
  |
BTC / EVM / Solana / TRON / XRP / etc.
```

## Non-negotiable accounting rule

Never update a wallet balance directly from an HTTP request or client-supplied amount.

All money movement must be represented as an immutable ledger transaction:

```text
User Wallet Liability
        <---->
Platform Treasury / Custody Account
```

Every entry must have:
- unique transaction ID
- asset
- amount in integer base units
- debit account
- credit account
- source/reference
- idempotency key
- status
- timestamps
- audit metadata

## Asset architecture

Coins and tokens are data-driven. Do not hard-code a fixed list of "top coins" into business logic.

Each asset defines:
- symbol
- canonical asset ID
- network
- contract address where applicable
- decimals
- deposit enabled
- withdrawal enabled
- trading enabled
- minimum deposit
- minimum withdrawal
- withdrawal fee
- confirmation policy
- explorer URL template
- risk tier

The initial production catalog can prioritize major assets such as BTC, ETH, USDT, USDC, SOL, XRP, BNB, DOGE, ADA, TRX, AVAX, LINK, LTC, BCH and DOT, but the actual enabled set must be controlled by an administrator/compliance approval workflow and current liquidity/custody support.

## Custody

Private keys must never be stored in the application database or `.env` files.

The custody layer must support:
- HSM-backed signing or institutional MPC custody
- hot wallet limits
- warm/cold segregation
- withdrawal policy engine
- multi-approval for high-risk withdrawals
- address allowlists
- velocity limits
- anomaly detection
- key rotation procedures
- emergency freeze
- disaster recovery

A custody provider adapter should be supported so the platform can begin with a vetted custody provider and later support self-custody infrastructure without changing wallet business logic.

## Blockchain processing

Deposits are asynchronous:

```text
Blockchain
  -> Indexer/Node
  -> Deposit Observer
  -> Confirmation Engine
  -> Risk/KYT checks
  -> Ledger credit
  -> User notification
```

Handle:
- chain reorganizations
- duplicate events
- replaced transactions
- insufficient confirmations
- token contract changes
- network congestion
- chain outages
- stuck transactions
- provider disagreement

## Withdrawals

```text
User request
  -> Authentication / MFA
  -> Address validation
  -> Risk/KYT screening
  -> Policy engine
  -> Ledger reservation
  -> Approval queue if required
  -> Custody signer
  -> Broadcast
  -> Confirmation tracking
  -> Final settlement
```

Withdrawal requests must be idempotent and state-machine driven. A failed broadcast must not create a second spendable balance.

## Spot matching engine

The matching engine must be deterministic and isolated from the web application.

For each market:
- price-time priority
- atomic matching
- sequence numbers
- deterministic trade IDs
- maker/taker classification
- fee calculation
- balance reservation before matching
- rollback/recovery strategy

The web/API layer should never execute matching logic directly.

## Market data

Separate market data from order execution:
- ticker service
- trades stream
- order book snapshots
- incremental order book events
- candles
- websocket feeds
- REST snapshots

Persist raw trade/order events where needed for reconciliation and auditability.

## Security targets

- passkeys/WebAuthn and MFA
- withdrawal MFA
- withdrawal allowlist
- session/device risk scoring
- IP and velocity controls
- API key scopes
- trading-only and withdrawal-disabled API keys
- encrypted secrets
- HSM/MPC signing
- immutable audit logs
- rate limiting
- replay protection
- idempotency keys
- segregation of duties
- emergency kill switches
- continuous reconciliation

## Reliability targets

- no double credit
- no double withdrawal
- no negative available balance
- deterministic order matching
- replay-safe blockchain events
- daily custody reconciliation
- automated discrepancy alerts
- tested backup/restore
- disaster-recovery runbooks

## Important boundary

This architecture is software engineering guidance, not a statement that ApkayA is authorized to operate a crypto exchange. Custodial wallet, fiat/crypto exchange, transfer, and related activities can be regulated. The production launch gate must include jurisdiction-specific legal/compliance review and required registrations/licensing.
