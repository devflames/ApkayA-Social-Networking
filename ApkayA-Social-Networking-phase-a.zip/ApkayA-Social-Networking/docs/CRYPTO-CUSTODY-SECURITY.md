# Crypto Custody Security Standard

## Core rule

The application never possesses raw private keys.

Preferred signing hierarchy:

```text
Cold Storage / Offline
        |
Warm Storage / Controlled
        |
Hot Wallet / Limited Float
        |
Application Withdrawal Queue
```

## Controls

1. HSM or MPC signing.
2. Separate custody credentials from application credentials.
3. No seed phrases in source control, environment files, database rows, logs, telemetry, or support tickets.
4. Per-asset and per-network hot-wallet limits.
5. Daily withdrawal limits.
6. Per-user velocity limits.
7. New-address cooling period where appropriate.
8. Withdrawal allowlist.
9. Manual approval thresholds.
10. Dual-control for treasury movement.
11. Automated blockchain reconciliation.
12. Immutable audit trail.
13. Emergency withdrawal freeze.
14. Key rotation and compromise procedures.
15. Tested disaster recovery.

## Reconciliation

At least daily, and preferably continuously for critical assets:

```text
Internal Ledger
      ==
Custody Provider / Node Balance
      ==
Expected User + Treasury Liabilities
```

Any discrepancy creates a high-priority incident and can automatically disable withdrawals for the affected asset/network.
