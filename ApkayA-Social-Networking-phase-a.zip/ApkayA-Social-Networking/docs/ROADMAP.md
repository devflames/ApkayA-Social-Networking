# ApkayA Social Networking Roadmap

## Phase 0 — Foundation
- [x] Repository architecture
- [x] Legacy-source boundary
- [x] Theme plugin contract
- [x] Crypto/exchange architecture
- [x] Sandbox asset registry
- [x] Exact integer ledger primitive
- [x] Paper spot order-book primitive
- [ ] Import licensed legacy application under `/legacy/wowonder-v4.3.4`

## Phase 1 — Security and identity
- [ ] Session hardening
- [ ] CSRF and origin validation
- [ ] RBAC/ABAC
- [ ] Passkeys/MFA
- [ ] Rate limiting
- [ ] Audit logging

## Phase 2 — Crypto wallet
- [ ] Durable database ledger
- [ ] Wallet/account state machines
- [ ] Deposit address abstraction
- [ ] Blockchain adapters
- [ ] Confirmation engine
- [ ] Withdrawal policy engine
- [ ] Reconciliation
- [ ] Custody provider adapter

## Phase 3 — Spot exchange
- [ ] Durable order state machine
- [ ] Deterministic matching engine
- [ ] Reservations/holds
- [ ] Trade settlement
- [ ] Maker/taker fees
- [ ] Market data streams
- [ ] WebSocket API

## Phase 4 — Social/creator/commerce migration
- [ ] Legacy adapters
- [ ] Social domain extraction
- [ ] Creator economy
- [ ] Marketplace
- [ ] AI gateway

## Phase 5 — Advanced exchange
- [ ] Stop/OCO orders
- [ ] API trading keys
- [ ] Subaccounts
- [ ] Proof-of-reserves reporting
- [ ] Institutional controls

## Phase 6 — Enterprise platform
- [ ] Theme marketplace
- [ ] Plugin marketplace
- [ ] White-label editions
- [ ] License/entitlement server
- [ ] Multi-tenant deployment
