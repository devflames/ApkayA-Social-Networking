# Architecture

## Target

The platform will evolve from a legacy PHP application into a modular platform while preserving compatibility during migration.

```text
Web / Mobile / Desktop / Integrations
                |
             API Layer
                |
       +--------+--------+
       |                 |
   Core Domains      Plugin Runtime
       |                 |
       |          +------+------+
       |          |             |
       |        Themes       Extensions
       |
 +-----+------+--------+--------+
 |            |        |        |
Auth       Social   Creator  Commerce
 |            |        |        |
 +------------+--------+--------+
              |
       Infrastructure
   DB / Redis / Queue / Storage
              |
        Media / AI / Realtime
```

## Migration strategy

1. Freeze and preserve a clean legacy baseline.
2. Introduce adapters around legacy services.
3. Move security-sensitive capabilities first.
4. Extract domain services incrementally.
5. Introduce queues, Redis and object storage.
6. Replace legacy UI with theme plugins.
7. Retire legacy modules only after parity tests pass.

## Non-negotiable boundaries

- UI must not contain payment/business rules.
- Themes must not access raw database connections.
- Plugins must declare permissions/capabilities.
- Financial operations must use transactional ledger services.
- Authentication must be centralized.
- Media processing must be asynchronous.
- External providers must be behind provider interfaces.
