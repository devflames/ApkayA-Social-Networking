# Security Baseline

Target: production-grade security rather than feature-only compatibility.

## P0

- Secure session cookies and session rotation
- CSRF protection for state-changing web requests
- Strict authorization/RBAC
- Server-side payment verification
- Immutable financial transaction ledger
- Upload MIME/magic-byte validation and quarantine
- Rate limiting and abuse controls
- HTTPS/HSTS
- Remove diagnostics such as public phpinfo endpoints
- Secrets outside source control

## P1

- Prepared SQL statements
- OAuth provider isolation
- API scopes
- CSP/security headers
- Admin MFA/passkeys
- Audit logging
- Dependency/SAST/DAST scanning
- Security regression tests

## Financial rule

Never trust client-supplied amount, user ID, currency, status, or transaction state when crediting money. Provider transaction IDs must be verified server-to-server and applied inside a database transaction.
