# Theme Plugin System

The theme system is a core architectural requirement. A customer must be able to install, activate, deactivate, replace, or build a theme without editing core application code.

## Goals

- Multiple themes can coexist in one installation.
- One theme is active per site/tenant/context.
- Themes can be purchased, uploaded, or developed internally.
- Theme upgrades are versioned and reversible.
- Core APIs/domain services remain theme-agnostic.
- Theme plugins can define templates, components, CSS, JS, tokens and assets.
- Theme plugins declare compatibility with platform versions.
- Theme plugins cannot silently gain privileged server capabilities.

## Proposed plugin structure

```text
plugins/themes/acme-modern/
├── theme.json
├── assets/
├── components/
├── layouts/
├── pages/
├── styles/
├── scripts/
├── locales/
├── screenshots/
└── README.md
```

## Example manifest

```json
{
  "id": "acme-modern",
  "name": "Acme Modern",
  "version": "1.0.0",
  "type": "theme",
  "engine": "v1",
  "requires": {
    "platform": ">=1.0.0 <2.0.0"
  },
  "entry": "layouts/app",
  "capabilities": [
    "theme.layouts",
    "theme.components",
    "theme.assets",
    "theme.navigation",
    "theme.tokens"
  ]
}
```

## Theme API

Core should expose stable view-model contracts such as:

- `UserViewModel`
- `PostViewModel`
- `FeedViewModel`
- `ConversationViewModel`
- `ProductViewModel`
- `CreatorViewModel`
- `NotificationViewModel`

Themes render these contracts instead of querying application tables.

## Design tokens

Every theme should be able to define:

- color palette
- typography
- spacing scale
- radius
- elevation
- motion
- breakpoints
- icon set
- component variants
- light/dark modes

## Theme lifecycle

```text
Upload/Install
      |
   Validate
      |
Compatibility Check
      |
   Activate
      |
     Run
      |
Deactivate / Rollback / Upgrade
```

## Marketplace-ready model

The future platform can support a theme marketplace where a theme package contains:

- license/entitlement ID
- version
- author/vendor
- screenshots
- changelog
- compatibility range
- signature/checksum
- optional support metadata

This licensing layer must only grant rights that the vendor actually owns and is authorized to grant.
