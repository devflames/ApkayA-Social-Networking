# Licensing and IP Boundary

## Purpose

This project began from a licensed third-party social-networking application. We must preserve a clear distinction between:

1. third-party source/assets that remain subject to their original licenses;
2. dependencies with their own licenses; and
3. newly authored ApkayA code, architecture, documentation and assets.

## Rules

- Do not claim ownership of third-party source merely because it is modified.
- Keep a record of the original package/version and license evidence.
- Do not remove copyright/license notices where the applicable license requires them.
- Do not build a licensing server that purports to grant rights we do not possess.
- Our licensing server may license ApkayA-owned modules, themes, extensions and editions where we have the rights to do so.
- Before commercial redistribution, verify the exact license terms for the original item and every dependency.

## Repository organization

```text
legacy/       # third-party/licensed material, isolated and documented
src/          # newly authored ApkayA platform code
plugins/      # our original plugins/themes
```

The repository currently contains no copied legacy application source. That is intentional until the import boundary is approved.
