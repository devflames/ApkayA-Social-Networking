<?php

declare(strict_types=1);

namespace ApkayA\Crypto\Ledger;

interface Ledger
{
    public function post(LedgerTransaction $transaction): void;
    public function hasIdempotencyKey(string $key): bool;
    public function available(string $accountId, string $assetKey): string;
}
