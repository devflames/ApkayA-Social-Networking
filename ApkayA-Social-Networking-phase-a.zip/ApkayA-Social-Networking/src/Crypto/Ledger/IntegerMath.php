<?php

declare(strict_types=1);

namespace ApkayA\Crypto\Ledger;

/** Exact non-negative integer arithmetic using decimal strings; no floating point. */
final class IntegerMath
{
    public static function normalize(string $value): string
    {
        if (!preg_match('/^(0|[1-9][0-9]*)$/', $value)) {
            throw new \InvalidArgumentException('Expected a non-negative integer string.');
        }
        return $value;
    }

    public static function add(string $a, string $b): string
    {
        self::normalize($a); self::normalize($b);
        $i = strlen($a) - 1; $j = strlen($b) - 1; $carry = 0; $out = '';
        while ($i >= 0 || $j >= 0 || $carry) {
            $sum = ($i >= 0 ? ord($a[$i--]) - 48 : 0) + ($j >= 0 ? ord($b[$j--]) - 48 : 0) + $carry;
            $out = ($sum % 10) . $out; $carry = intdiv($sum, 10);
        }
        return ltrim($out, '0') ?: '0';
    }

    public static function compare(string $a, string $b): int
    {
        self::normalize($a); self::normalize($b);
        if (strlen($a) !== strlen($b)) return strlen($a) <=> strlen($b);
        return $a <=> $b;
    }

    public static function sub(string $a, string $b): string
    {
        if (self::compare($a, $b) < 0) throw new \InvalidArgumentException('Integer subtraction would become negative.');
        $i = strlen($a) - 1; $j = strlen($b) - 1; $borrow = 0; $out = '';
        while ($i >= 0) {
            $d = ord($a[$i--]) - 48 - $borrow;
            $e = $j >= 0 ? ord($b[$j--]) - 48 : 0;
            if ($d < $e) { $d += 10; $borrow = 1; } else { $borrow = 0; }
            $out = ($d - $e) . $out;
        }
        return ltrim($out, '0') ?: '0';
    }
}
