<?php

declare(strict_types=1);

namespace ApkayA\Crypto\Ledger;

final readonly class LedgerTransaction
{
    /** @param list<LedgerEntry> $entries */
    public function __construct(
        public string $id,
        public string $idempotencyKey,
        public string $source,
        public array $entries,
        public \DateTimeImmutable $createdAt,
        public array $metadata = [],
    ) {}
}
