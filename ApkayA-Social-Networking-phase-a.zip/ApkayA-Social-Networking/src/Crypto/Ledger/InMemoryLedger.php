<?php

declare(strict_types=1);

namespace ApkayA\Crypto\Ledger;

final class InMemoryLedger implements Ledger
{
    /** @var array<string, LedgerTransaction> */
    private array $transactions = [];
    /** @var array<string, string> */
    private array $balances = [];
    /** @var array<string, true> */
    private array $idempotency = [];

    /** Sandbox-only funding helper; production ledgers must use an auditable opening-balance transaction. */
    public function seedForSandbox(string $accountId, string $assetKey, string $amount): void
    {
        IntegerMath::normalize($amount);
        $key = $accountId . '|' . $assetKey;
        $this->balances[$key] = IntegerMath::add($this->balances[$key] ?? '0', $amount);
    }

    public function post(LedgerTransaction $transaction): void
    {
        if ($this->hasIdempotencyKey($transaction->idempotencyKey)) return;
        if ($transaction->entries === []) throw new \InvalidArgumentException('Ledger transaction requires entries.');

        $debits = $credits = '0';
        $deltas = [];
        foreach ($transaction->entries as $entry) {
            if (!$entry instanceof LedgerEntry) throw new \InvalidArgumentException('Invalid ledger entry.');
            $key = $entry->accountId . '|' . $entry->assetKey;
            $current = $deltas[$key] ?? '0';
            if ($entry->direction === 'credit') {
                $deltas[$key] = self::signedAdd($current, $entry->amount);
                $credits = IntegerMath::add($credits, $entry->amount);
            } else {
                $deltas[$key] = self::signedSub($current, $entry->amount);
                $debits = IntegerMath::add($debits, $entry->amount);
            }
        }
        if ($debits !== $credits) throw new \InvalidArgumentException('Ledger transaction is not balanced.');

        // Validate all resulting balances before applying anything (atomicity).
        foreach ($deltas as $key => $delta) {
            [$accountId, $assetKey] = explode('|', $key, 2);
            $before = $this->balances[$key] ?? '0';
            if ($delta[0] !== '-') continue;
            $required = substr($delta, 1);
            if (IntegerMath::compare($before, $required) < 0) {
                throw new \RuntimeException("Insufficient balance for {$accountId} / {$assetKey}");
            }
        }

        foreach ($deltas as $key => $delta) {
            $before = $this->balances[$key] ?? '0';
            if ($delta[0] === '-') {
                $this->balances[$key] = IntegerMath::sub($before, substr($delta, 1));
            } else {
                $this->balances[$key] = IntegerMath::add($before, $delta);
            }
        }
        $this->transactions[$transaction->id] = $transaction;
        $this->idempotency[$transaction->idempotencyKey] = true;
    }

    private static function signedAdd(string $current, string $amount): string
    {
        if ($current === '0' || $current[0] !== '-') return IntegerMath::add($current, $amount);
        $negative = substr($current, 1);
        $cmp = IntegerMath::compare($negative, $amount);
        if ($cmp === 0) return '0';
        if ($cmp > 0) return '-' . IntegerMath::sub($negative, $amount);
        return IntegerMath::sub($amount, $negative);
    }

    private static function signedSub(string $current, string $amount): string
    {
        if ($current === '0') return '-' . $amount;
        if ($current[0] !== '-') {
            return IntegerMath::compare($current, $amount) >= 0
                ? IntegerMath::sub($current, $amount)
                : '-' . IntegerMath::sub($amount, $current);
        }
        return '-' . IntegerMath::add(substr($current, 1), $amount);
    }

    public function hasIdempotencyKey(string $key): bool { return isset($this->idempotency[$key]); }
    public function available(string $accountId, string $assetKey): string { return $this->balances[$accountId . '|' . $assetKey] ?? '0'; }
}
