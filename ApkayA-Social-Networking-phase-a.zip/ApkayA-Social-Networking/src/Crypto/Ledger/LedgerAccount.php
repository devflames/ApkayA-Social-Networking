<?php

declare(strict_types=1);

namespace ApkayA\Crypto\Ledger;

final readonly class LedgerAccount
{
    public function __construct(
        public string $id,
        public string $ownerType,
        public string $ownerId,
        public string $assetKey,
        public string $kind = 'liability',
    ) {}
}
