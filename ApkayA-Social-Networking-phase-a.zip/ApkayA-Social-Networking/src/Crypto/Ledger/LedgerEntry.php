<?php

declare(strict_types=1);

namespace ApkayA\Crypto\Ledger;

final readonly class LedgerEntry
{
    public function __construct(
        public string $accountId,
        public string $assetKey,
        public string $amount,
        public string $direction,
    ) {
        IntegerMath::normalize($amount);
        if (!in_array($direction, ['debit', 'credit'], true)) throw new \InvalidArgumentException('Invalid ledger direction.');
    }
}
