<?php

declare(strict_types=1);

namespace ApkayA\Crypto\Assets;

use ApkayA\Crypto\Domain\Asset;

final class AssetRegistry
{
    /** @var array<string, Asset> */
    private array $assets = [];

    public function register(Asset $asset): void
    {
        $key = $asset->key();
        if (isset($this->assets[$key])) {
            throw new \LogicException("Asset/network already registered: {$key}");
        }
        $this->assets[$key] = $asset;
    }

    public function get(string $symbol, string $network): Asset
    {
        $key = strtolower($symbol . ':' . $network);
        if (!isset($this->assets[$key])) {
            throw new \OutOfBoundsException("Unknown asset/network: {$key}");
        }
        return $this->assets[$key];
    }

    /** @return list<Asset> */
    public function all(): array
    {
        return array_values($this->assets);
    }
}
