# Crypto Domain

This subsystem is now entering **Phase A: deterministic sandbox ledger + asset registry + paper spot matching**.

Implemented foundation:
- Exact integer arithmetic using decimal strings; no floating-point monetary values.
- Balanced immutable-style ledger transactions with idempotency keys and atomic preflight validation.
- Data-driven asset/network registry.
- Deterministic price-time-priority paper order book.

Production gates still required before real funds:
- PostgreSQL/MySQL durable ledger with database transactions and constraints.
- HSM/MPC custody provider.
- Blockchain node/indexer adapters.
- KYT/KYC/compliance controls.
- Reconciliation engine.
- Security review and penetration testing.

Never put private keys, seed phrases, custody secrets, real credentials, or production wallet addresses in this repository.

## Durable schema

`database/migrations/0001_crypto_core.sql` defines the PostgreSQL foundation for assets, accounts, immutable ledger entries, addresses, chain transactions, withdrawals, markets, orders, trades and audit events.
