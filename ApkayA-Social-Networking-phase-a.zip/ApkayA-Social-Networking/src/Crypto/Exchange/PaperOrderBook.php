<?php

declare(strict_types=1);

namespace ApkayA\Crypto\Exchange;

use ApkayA\Crypto\Ledger\IntegerMath;

/** Deterministic price-time-priority matching for sandbox/paper trading. */
final class PaperOrderBook
{
    /** @var list<Order> */
    private array $buys = [];
    /** @var list<Order> */
    private array $sells = [];

    public function add(Order $order): array
    {
        if ($order->side === 'buy') $this->buys[] = $order; else $this->sells[] = $order;
        $this->sort();
        $trades = [];
        while ($this->buys && $this->sells && $this->buys[0]->price >= $this->sells[0]->price) {
            $buy = $this->buys[0]; $sell = $this->sells[0];
            $qty = IntegerMath::compare($buy->quantity, $sell->quantity) <= 0 ? $buy->quantity : $sell->quantity;
            $trades[] = ['buyOrderId'=>$buy->id,'sellOrderId'=>$sell->id,'price'=>$sell->price,'quantity'=>$qty];
            $this->buys = $this->consume($this->buys, $qty);
            $this->sells = $this->consume($this->sells, $qty);
            $this->sort();
        }
        return $trades;
    }

    /** @param list<Order> $orders */
    private function consume(array $orders, string $qty): array
    {
        $first = array_shift($orders);
        if ($first === null) return $orders;
        $remaining = $this->subtract($first->quantity, $qty);
        if ($remaining !== '0') $orders[] = new Order($first->id, $first->userId, $first->side, $first->price, $remaining, $first->sequence);
        return array_values($orders);
    }

    private function subtract(string $a, string $b): string
    {
        if (IntegerMath::compare($a, $b) < 0) throw new \LogicException('Order quantity underflow.');
        $i=strlen($a)-1;$j=strlen($b)-1;$borrow=0;$out='';
        while($i>=0){$d=ord($a[$i--])-48-$borrow;$e=$j>=0?ord($b[$j--])-48:0;if($d<$e){$d+=10;$borrow=1;}else{$borrow=0;}$out=($d-$e).$out;}
        return ltrim($out,'0')?:'0';
    }

    private function sort(): void
    {
        usort($this->buys, fn(Order $a, Order $b) => $a->price === $b->price ? $a->sequence <=> $b->sequence : -IntegerMath::compare($a->price, $b->price));
        usort($this->sells, fn(Order $a, Order $b) => $a->price === $b->price ? $a->sequence <=> $b->sequence : IntegerMath::compare($a->price, $b->price));
    }
}
