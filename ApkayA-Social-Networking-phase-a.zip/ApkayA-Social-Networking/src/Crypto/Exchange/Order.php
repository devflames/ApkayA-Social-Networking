<?php

declare(strict_types=1);

namespace ApkayA\Crypto\Exchange;

final readonly class Order
{
    public function __construct(
        public string $id,
        public string $userId,
        public string $side,
        public string $price,
        public string $quantity,
        public int $sequence,
    ) {
        if (!in_array($side, ['buy', 'sell'], true)) throw new \InvalidArgumentException('Invalid order side.');
        if (!preg_match('/^[1-9][0-9]*$/', $price) || !preg_match('/^[1-9][0-9]*$/', $quantity)) throw new \InvalidArgumentException('Price and quantity must be positive integer base units.');
    }
}
