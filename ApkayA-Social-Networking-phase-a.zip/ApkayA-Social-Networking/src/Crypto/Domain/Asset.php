<?php

declare(strict_types=1);

namespace ApkayA\Crypto\Domain;

final readonly class Asset
{
    public function __construct(
        public string $id,
        public string $symbol,
        public string $network,
        public int $decimals,
        public bool $enabled = false,
        public bool $depositEnabled = false,
        public bool $withdrawalEnabled = false,
        public bool $tradingEnabled = false,
    ) {
        if ($decimals < 0 || $decimals > 36) {
            throw new \InvalidArgumentException('Asset decimals must be between 0 and 36.');
        }
    }

    public function key(): string
    {
        return strtolower($this->symbol . ':' . $this->network);
    }
}
