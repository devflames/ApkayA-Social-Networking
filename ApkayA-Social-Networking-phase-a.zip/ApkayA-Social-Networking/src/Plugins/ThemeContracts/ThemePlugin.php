<?php

declare(strict_types=1);

namespace ApkayA\Social\Plugins\ThemeContracts;

interface ThemePlugin
{
    public function id(): string;

    public function name(): string;

    public function version(): string;

    /** @return array<string, string> */
    public function metadata(): array;

    /** @return array<string> */
    public function capabilities(): array;

    public function activate(): void;

    public function deactivate(): void;
}
