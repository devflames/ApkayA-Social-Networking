# Theme Plugins

This directory will contain first-party and customer-installable UI themes.

Themes must depend on stable contracts from `src/Plugins/ThemeContracts` and must not reach directly into legacy globals or database tables.
