<?php

declare(strict_types=1);

require __DIR__ . '/../src/Crypto/Ledger/IntegerMath.php';
require __DIR__ . '/../src/Crypto/Ledger/LedgerEntry.php';
require __DIR__ . '/../src/Crypto/Ledger/LedgerTransaction.php';
require __DIR__ . '/../src/Crypto/Ledger/Ledger.php';
require __DIR__ . '/../src/Crypto/Ledger/InMemoryLedger.php';
require __DIR__ . '/../src/Crypto/Domain/Asset.php';
require __DIR__ . '/../src/Crypto/Assets/AssetRegistry.php';
require __DIR__ . '/../src/Crypto/Exchange/Order.php';
require __DIR__ . '/../src/Crypto/Exchange/PaperOrderBook.php';

use ApkayA\Crypto\Domain\Asset;
use ApkayA\Crypto\Assets\AssetRegistry;
use ApkayA\Crypto\Ledger\{InMemoryLedger, LedgerEntry, LedgerTransaction};
use ApkayA\Crypto\Exchange\{Order, PaperOrderBook};

assert(ApkayA\Crypto\Ledger\IntegerMath::add('999999999999999999999999', '1') === '1000000000000000000000000');

$registry = new AssetRegistry();
$registry->register(new Asset('btc:bitcoin', 'BTC', 'bitcoin', 8, false));
assert($registry->get('BTC', 'bitcoin')->decimals === 8);

$ledger = new InMemoryLedger();
$ledger->seedForSandbox('treasury', 'BTC:bitcoin', '25000000');
$tx = new LedgerTransaction('tx-1', 'deposit-1', 'sandbox.deposit', [
    new LedgerEntry('treasury', 'BTC:bitcoin', '25000000', 'debit'),
    new LedgerEntry('user-1', 'BTC:bitcoin', '25000000', 'credit'),
], new DateTimeImmutable());
$ledger->post($tx);
$ledger->post($tx); // idempotent replay must be a no-op
assert($ledger->available('user-1', 'BTC:bitcoin') === '25000000');

$book = new PaperOrderBook();
$book->add(new Order('sell-1', 'seller', 'sell', '100', '5', 1));
$trades = $book->add(new Order('buy-1', 'buyer', 'buy', '100', '3', 2));
assert(count($trades) === 1 && $trades[0]['quantity'] === '3' && $trades[0]['price'] === '100');

echo "Crypto smoke tests passed.\n";
