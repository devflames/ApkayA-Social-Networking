-- ApkayA Crypto Core — PostgreSQL
-- Sandbox/production foundation. No private keys or secrets belong in this schema.

create extension if not exists pgcrypto;

create table if not exists crypto_assets (
  id uuid primary key default gen_random_uuid(),
  symbol varchar(32) not null,
  name varchar(128) not null,
  network varchar(64) not null,
  contract_address varchar(256),
  decimals smallint not null check (decimals between 0 and 36),
  enabled boolean not null default false,
  deposits_enabled boolean not null default false,
  withdrawals_enabled boolean not null default false,
  trading_enabled boolean not null default false,
  min_deposit_base_units numeric(78,0) not null default 0 check (min_deposit_base_units >= 0),
  min_withdrawal_base_units numeric(78,0) not null default 0 check (min_withdrawal_base_units >= 0),
  withdrawal_fee_base_units numeric(78,0) not null default 0 check (withdrawal_fee_base_units >= 0),
  confirmation_count integer not null default 1 check (confirmation_count >= 0),
  explorer_tx_template text,
  risk_tier varchar(32) not null default 'standard',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(symbol, network, contract_address)
);

create table if not exists crypto_accounts (
  id uuid primary key default gen_random_uuid(),
  owner_type varchar(32) not null,
  owner_id varchar(191) not null,
  account_kind varchar(32) not null,
  asset_id uuid not null references crypto_assets(id),
  status varchar(32) not null default 'active',
  created_at timestamptz not null default now(),
  unique(owner_type, owner_id, account_kind, asset_id)
);

create table if not exists crypto_ledger_transactions (
  id uuid primary key default gen_random_uuid(),
  idempotency_key varchar(191) not null unique,
  source varchar(128) not null,
  reference_type varchar(64),
  reference_id varchar(191),
  status varchar(32) not null default 'posted',
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists crypto_ledger_entries (
  id uuid primary key default gen_random_uuid(),
  transaction_id uuid not null references crypto_ledger_transactions(id) on delete restrict,
  account_id uuid not null references crypto_accounts(id) on delete restrict,
  asset_id uuid not null references crypto_assets(id) on delete restrict,
  direction varchar(8) not null check (direction in ('debit','credit')),
  amount_base_units numeric(78,0) not null check (amount_base_units > 0),
  created_at timestamptz not null default now()
);

create index if not exists idx_crypto_ledger_entries_account_asset
  on crypto_ledger_entries(account_id, asset_id, created_at);

create index if not exists idx_crypto_ledger_entries_transaction
  on crypto_ledger_entries(transaction_id);

create table if not exists crypto_wallet_addresses (
  id uuid primary key default gen_random_uuid(),
  account_id uuid not null references crypto_accounts(id) on delete restrict,
  asset_id uuid not null references crypto_assets(id) on delete restrict,
  address varchar(512) not null,
  memo_tag varchar(256),
  provider_reference varchar(191),
  status varchar(32) not null default 'active',
  created_at timestamptz not null default now(),
  unique(asset_id, address, memo_tag)
);

create table if not exists crypto_chain_transactions (
  id uuid primary key default gen_random_uuid(),
  asset_id uuid not null references crypto_assets(id),
  tx_hash varchar(256) not null,
  direction varchar(16) not null check (direction in ('deposit','withdrawal')),
  status varchar(32) not null,
  confirmations integer not null default 0 check (confirmations >= 0),
  block_height bigint,
  block_hash varchar(256),
  amount_base_units numeric(78,0),
  metadata jsonb not null default '{}'::jsonb,
  first_seen_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(asset_id, tx_hash, direction)
);

create table if not exists crypto_withdrawals (
  id uuid primary key default gen_random_uuid(),
  account_id uuid not null references crypto_accounts(id),
  asset_id uuid not null references crypto_assets(id),
  address varchar(512) not null,
  memo_tag varchar(256),
  amount_base_units numeric(78,0) not null check (amount_base_units > 0),
  fee_base_units numeric(78,0) not null default 0 check (fee_base_units >= 0),
  status varchar(32) not null default 'requested',
  idempotency_key varchar(191) not null unique,
  risk_score numeric(12,4),
  approval_required boolean not null default true,
  provider_reference varchar(191),
  chain_transaction_id uuid references crypto_chain_transactions(id),
  requested_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists crypto_markets (
  id uuid primary key default gen_random_uuid(),
  symbol varchar(64) not null unique,
  base_asset_id uuid not null references crypto_assets(id),
  quote_asset_id uuid not null references crypto_assets(id),
  status varchar(32) not null default 'disabled',
  price_scale smallint not null default 18 check (price_scale between 0 and 36),
  quantity_scale smallint not null default 18 check (quantity_scale between 0 and 36),
  maker_fee_bps integer not null default 0 check (maker_fee_bps >= 0),
  taker_fee_bps integer not null default 0 check (taker_fee_bps >= 0),
  created_at timestamptz not null default now(),
  unique(base_asset_id, quote_asset_id)
);

create table if not exists crypto_orders (
  id uuid primary key default gen_random_uuid(),
  market_id uuid not null references crypto_markets(id),
  user_id varchar(191) not null,
  side varchar(8) not null check (side in ('buy','sell')),
  order_type varchar(16) not null check (order_type in ('limit','market','stop','stop_limit','oco')),
  status varchar(32) not null default 'open',
  price_numerator numeric(78,0),
  price_denominator numeric(78,0),
  quantity_base_units numeric(78,0) not null check (quantity_base_units > 0),
  filled_base_units numeric(78,0) not null default 0 check (filled_base_units >= 0),
  reserved_quote_base_units numeric(78,0) not null default 0 check (reserved_quote_base_units >= 0),
  sequence bigint not null,
  idempotency_key varchar(191) not null unique,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (price_numerator is null or price_numerator > 0),
  check (price_denominator is null or price_denominator > 0),
  check (filled_base_units <= quantity_base_units)
);

create index if not exists idx_crypto_orders_market_book
  on crypto_orders(market_id, side, status, sequence);

create table if not exists crypto_trades (
  id uuid primary key default gen_random_uuid(),
  market_id uuid not null references crypto_markets(id),
  maker_order_id uuid not null references crypto_orders(id),
  taker_order_id uuid not null references crypto_orders(id),
  price_numerator numeric(78,0) not null,
  price_denominator numeric(78,0) not null,
  quantity_base_units numeric(78,0) not null check (quantity_base_units > 0),
  maker_fee_base_units numeric(78,0) not null default 0,
  taker_fee_base_units numeric(78,0) not null default 0,
  sequence bigint not null,
  executed_at timestamptz not null default now()
);

create index if not exists idx_crypto_trades_market_time
  on crypto_trades(market_id, executed_at desc);

create table if not exists crypto_audit_events (
  id uuid primary key default gen_random_uuid(),
  actor_type varchar(32) not null,
  actor_id varchar(191),
  event_type varchar(128) not null,
  entity_type varchar(64),
  entity_id varchar(191),
  request_id varchar(191),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists idx_crypto_audit_events_entity
  on crypto_audit_events(entity_type, entity_id, created_at desc);
