# Legacy Source Boundary

The original licensed WoWonder package will be staged here only after the licensing/source inventory is finalized.

Do not mix newly authored ApkayA code into this directory.
