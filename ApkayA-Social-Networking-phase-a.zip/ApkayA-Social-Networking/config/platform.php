<?php

declare(strict_types=1);

return [
    'name' => 'ApkayA Social Networking',
    'architecture_version' => '0.1.0',
    'theme_engine_version' => '1',
    'default_theme' => 'apkaya-default',
];
