# ApkayA Social Networking

A modernization project for a modular, secure, extensible social-networking platform.

> **Important licensing boundary:** this repository is being structured so original third-party/licensed source remains identifiable and isolated from newly authored ApkayA code. The original WoWonder/Envato license does not transfer ownership of the original item. See `docs/LICENSING-BOUNDARY.md` before redistributing any derivative or commercial edition.

## Vision

Build a production-grade Social + Creator + AI + Commerce platform with a plugin-first architecture.

### Core product areas

- Social feed, posts, comments, reactions, stories and reels
- Profiles, pages, groups, events and forums
- Messaging and realtime presence
- Creator subscriptions, tips, paid content and payouts
- Marketplace, orders, sellers and commerce
- Live/video/media processing
- AI assistant, generation, moderation and recommendations
- Search, analytics, notifications and moderation
- API-first integrations, webhooks and extensions
- Pluggable UI themes and design systems
- Enterprise/white-label editions

## Architecture principle

**The UI/theme system is a first-class plugin system.** Core product logic must not depend on one visual theme.

```text
Core Platform
├── Domain/API
├── Auth/Security
├── Social
├── Creator
├── Commerce
├── AI
├── Media
├── Realtime
└── Plugin Runtime
    └── Themes
        ├── Default Theme
        ├── Custom Theme A
        ├── Custom Theme B
        └── Customer Theme Plugins
```

A theme plugin may provide layouts, components, tokens, assets, navigation, branding and optional UI capabilities without modifying core business logic.

## Repository status

This initial commit is the **architecture/foundation layer**. The licensed legacy application is intentionally not copied into this repository yet. It will be imported only after the source/license boundary and migration plan are finalized.

See:

- `docs/ARCHITECTURE.md`
- `docs/THEME-PLUGIN-SYSTEM.md`
- `docs/ROADMAP.md`
- `docs/LICENSING-BOUNDARY.md`
- `docs/SECURITY-BASELINE.md`

## Crypto / Exchange Platform

ApkayA is designed to include a first-class crypto wallet and spot-exchange subsystem. The wallet is based on immutable double-entry accounting, data-driven multi-chain assets, asynchronous blockchain processing, custody abstraction, reconciliation, and a separate deterministic matching engine.

The design supports major assets and additional networks through adapters rather than hard-coded coin logic. Real-money custody and public exchange operation are disabled until security, custody, compliance, licensing, and reconciliation gates are completed.

See:
- `docs/CRYPTO-EXCHANGE-ARCHITECTURE.md`
- `docs/CRYPTO-CUSTODY-SECURITY.md`
- `docs/CRYPTO-COMPLIANCE-GATE.md`
- `config/crypto/assets.example.json`
